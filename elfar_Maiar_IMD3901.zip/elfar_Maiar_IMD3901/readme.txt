﻿My game theme is a soccer field. There is an animation of a soccer ball getting to the net. Aswell there is a button once clicked on a green plane will appear in the billboard showing the player won. 


I choose this design because i love sports, also having a billboard telling the score is more appealing, and makes it obvious of what's happening, and what to do.


It was a challenge for sure. After the prof let me get an extension for a couple of hours I was able to get a few things extra done.